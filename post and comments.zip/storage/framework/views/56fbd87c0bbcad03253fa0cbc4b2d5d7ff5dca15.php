<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <?php if(session('success-status')): ?>
                <div class="alert alert-success">
                        <?php echo e(session('success-status')); ?>

                </div>
            <?php endif; ?>
            <div class="card">
                <div class="card-header">Posts</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <form method="POST" action="<?php echo e(route('post.store')); ?>">
                        <?php echo csrf_field(); ?>
                        <textarea name="body" class="form-control"> </textarea>   
                        <input type="submit" name="submit" value="submit">
                    </form>

                </div>
            </div>
            <br>
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card">
                    <div class="card-body">
                        <?php echo e($post->body); ?>

                    </div>
                        <span class="badge">
                         <?php echo e(count($post->likes)); ?> Likes
                         </span>
                     <div class="card-header">
                        <?php if(count($post->likes) === 0): ?>
                             <a type="button" href="<?php echo e(route('post.like',$post->id)); ?>"> 
                                <i class="fa fa-thumbs-o-up" aria-hidden="true"></i>
                              </a>
                        <?php endif; ?>
                         <a href="<?php echo e(route('post.dislike',$post->id)); ?>" type="button">
                             <i class="fa fa-thumbs-o-down" aria-hidden="true"></i>
                         </a>
                     </div>
                     <div class="card-header">
                        <form method = "POST" action="<?php echo e(route('comment.store')); ?>">
                            <?php echo csrf_field(); ?>
                        <input type="hidden" name="post_id" value="<?php echo e($post->id); ?>">
                         <label>Place your comments here</label>
                         <textarea name="body" cols="70"> </textarea>
                         <input type="submit" name="submit" value="Add your comment">
                        </form>
                        <ul style="padding:20px">
                            <?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($comment->body); ?> <span class="pull-right"><?php echo e($comment->user->name); ?></span>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>

                     </div>
                </div>
            <br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>