<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">
		<?php if($errors->any()): ?>
		    <div class="alert alert-danger">
		        <ul>
		            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                <li><?php echo e($error); ?></li>
		            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		        </ul>
		    </div>
		<?php endif; ?>
	<form method="POST" role="form" action="<?php echo e(route('post.store')); ?>" class="col-md-5">
		<?php echo csrf_field(); ?>
	  <div class="form-group">
	    <label for="exampleInputEmail1">Title</label>
	    <input name="title" type="text" class="form-control" id="exampleInputEmail1" placeholder="Title">
	  </div>
	  <div class="form-group">
	    <label for="exampleInputEmail1">Body</label>
	  <textarea name="body" class="form-control" rows="3"></textarea>
	</div>
	  <button type="submit" class="btn btn-default">Submit</button>
	</form>
	</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>