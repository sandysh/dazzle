<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="row">
      <div class="col-md-12">
          <a type="button" href="<?php echo e(route('post.create')); ?>" class="btn btn-default">Add New Post</a>
          <div></div>
          <table class="table table-bordered">
          <thead>
              <tr>
                  <th>ID</th>
                  <th>Title</th>
                  <th>Body</th>
                  <th>User</th>
                  <th width="20%">Actions</th>
              </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($post->id); ?></td>
                <td><?php echo e($post->title); ?></td>
                <td><?php echo e($post->body); ?></td>
                <td><?php echo e($post->user->name); ?></td>
                <td>
                  <a type="button" class="btn btn-info" href="<?php echo e(route('post.edit',$post->id)); ?>">Edit</a>
                    <a type="button" class="btn btn-danger" href="<?php echo e(route('post.delete',$post->id)); ?>">Delete</a>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
      </table>        
      </div>
    </div>
  </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>