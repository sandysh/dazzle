<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">
	<form method="POST" role="form" action="<?php echo e(route('post.update',$post->id)); ?>" class="col-md-5">
		<?php echo csrf_field(); ?>
	  <div class="form-group">
	    <label for="exampleInputEmail1">Title</label>
	    <input value="<?php echo e($post->title); ?>" name="title" type="text" class="form-control" id="exampleInputEmail1" placeholder="Title">
	  </div>
	  <div class="form-group">
	    <label for="exampleInputEmail1">Body</label>
	  <textarea name="body" class="form-control" rows="3"><?php echo e($post->body); ?></textarea>
	</div>
	  <button type="submit" class="btn btn-default">Submit</button>
	</form>
	</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>